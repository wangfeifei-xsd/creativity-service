---
name: configured-source
description: 根据授权源结果组织输出。
---

将查询步骤的真实结构化数据写入 data，保留来源引用，不添加源端未返回的数据。空结果与错误遵守源服务契约。参考 [输出规则](references/output.md)。
